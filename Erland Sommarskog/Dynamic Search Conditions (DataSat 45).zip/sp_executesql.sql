USE Northgale
go
DECLARE @sql    nvarchar(MAX),
        @params nvarchar(4000)
        
DECLARE @cnt    int,
        @cnt2   int

SELECT @sql = N'SELECT @cnt = COUNT(*)
                FROM   dbo.Orders
                WHERE  CustomerID = @custid'

SELECT @params = N'@custid nchar(5),
                   @cnt    int OUTPUT'

EXEC sp_executesql @sql, @params, N'BERGS', @cnt OUTPUT

EXEC sp_executesql @sql, 
                   N'@custid nchar(5), @cnt int OUTPUT', 
                   @custid = N'VINET', @cnt = @cnt2 OUTPUT
SELECT @cnt, @cnt2 

