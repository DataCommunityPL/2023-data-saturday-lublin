SET NOCOUNT ON
USE Northgale
go
CREATE OR ALTER PROCEDURE static_search_2
       @orderid     int          = NULL,
       @status      char(1)      = NULL,
       @fromdate    date         = NULL,
       @todate      date         = NULL,
       @custid      nchar(5)     = NULL,
       @custname    nvarchar(40) = NULL,
       @city        nvarchar(25) = NULL,
       @region      nvarchar(15) = NULL,
       @prodid      int          = NULL,
       @prodname    nvarchar(40) = NULL AS

SELECT o.OrderID, o.OrderDate, od.UnitPrice, od.Quantity,
       c.CustomerID, c.CustomerName, c.Address, c.City, c.Region,
       c.PostalCode, c.Country, c.Phone, p.ProductID,
       p.ProductName, p.UnitsInStock, p.UnitsOnOrder, o.EmployeeID
FROM   Orders o
JOIN   [Order Details] od ON o.OrderID = od.OrderID
JOIN   Customers c ON o.CustomerID = c.CustomerID
JOIN   Products p ON p.ProductID = od.ProductID
WHERE  o.OrderID = isnull(@orderid, o.OrderID)
  AND  o.Status = isnull(@status, o.Status)
  AND  o.OrderDate >= isnull(@fromdate, o.OrderDate)
  AND  o.OrderDate <= isnull(@todate, o.OrderDate)
  AND  o.CustomerID = isnull(@custid, o.CustomerID)
  AND  c.CustomerName LIKE isnull(@custname + '%', c.CustomerName)
  AND  c.City = isnull(@city, c.City)
  AND  c.Region = isnull(@region, c.Region)
  AND  od.ProductID = isnull(@prodid, od.ProductID)
  AND  p.ProductName LIKE isnull(@prodname + '%', p.ProductName)
ORDER  BY o.OrderID
go
EXEC static_search_2 @orderid = 11000
go
